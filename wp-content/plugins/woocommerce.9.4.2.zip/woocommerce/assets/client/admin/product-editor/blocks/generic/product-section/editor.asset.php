<?php return array('version' => 'cc7bac3ab4ef4370cdd1');
