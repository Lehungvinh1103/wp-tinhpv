<?php return array('dependencies' => array('lodash', 'wc-settings', 'wp-element', 'wp-hooks', 'wp-i18n', 'wp-url'), 'version' => '52484465f3135c108738');
