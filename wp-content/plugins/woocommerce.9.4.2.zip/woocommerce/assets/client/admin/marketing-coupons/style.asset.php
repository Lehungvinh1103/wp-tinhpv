<?php return array('version' => '71a31392c8405492fd18');
