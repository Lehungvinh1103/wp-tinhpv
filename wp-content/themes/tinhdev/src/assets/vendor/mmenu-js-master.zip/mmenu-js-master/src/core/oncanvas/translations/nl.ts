export default {
    'Close submenu': 'Submenu sluiten',
	'Menu': 'Menu',
    'Open submenu': 'Submenu openen',
    'Toggle submenu': 'Submenu wisselen'
};