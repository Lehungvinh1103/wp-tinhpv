export default {
    'cancel': 'скасувати',
    'Cancel searching': 'Скасувати пошук',
    'Clear searchfield': 'Очистити поле пошуку',
    'No results found.': 'Нічого не знайдено.',
    'Search': 'Пошук',
}