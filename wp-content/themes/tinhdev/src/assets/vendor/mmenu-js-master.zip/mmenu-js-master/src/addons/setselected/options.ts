const options : mmOptionsSetselected = {
	current: true,
	hover: false,
	parent: false
};

export default options;
