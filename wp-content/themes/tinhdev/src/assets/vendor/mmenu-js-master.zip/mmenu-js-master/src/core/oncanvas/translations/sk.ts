export default {
    'Close submenu': 'Zatvoriť submenu',
	'Menu': 'Menu',
    'Open submenu': 'Otvoriť submenu',
    'Toggle submenu': 'Prepnúť submenu'
}; 