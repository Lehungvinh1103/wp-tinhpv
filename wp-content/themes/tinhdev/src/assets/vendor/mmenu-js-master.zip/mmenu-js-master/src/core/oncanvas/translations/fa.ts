export default {
    'Close submenu': 'بستن زیرمنو',
	'Menu': 'منو',
    'Open submenu': 'بازکردن زیرمنو',
    'Toggle submenu': 'سوییچ زیرمنو'
};
