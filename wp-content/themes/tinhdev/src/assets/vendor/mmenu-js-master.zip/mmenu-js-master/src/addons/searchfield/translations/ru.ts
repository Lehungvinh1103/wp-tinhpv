export default {
    'cancel': 'отменить',
    'Cancel searching': 'Отменить поиск',
    'Clear searchfield': 'Очистить поле поиска',
    'No results found.': 'Ничего не найдено.',
    'Search': 'Найти',
};
