const options: mmOptionsSearchfield = {
    add: false,
    addTo: 'panels',
    noResults: 'No results found.',
    placeholder: 'Search',
    search: true,
    searchIn: 'panels',
    splash: '',
    title: 'Search',
};
export default options;
