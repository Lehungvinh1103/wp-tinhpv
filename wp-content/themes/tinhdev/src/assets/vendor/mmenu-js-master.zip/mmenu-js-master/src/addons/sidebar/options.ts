const options: mmOptionsSidebar = {
    collapsed: {
        use: false,
    },
    expanded: {
        use: false,
        initial: 'open'
    }
};
export default options;
