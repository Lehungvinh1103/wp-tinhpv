export default {
    'Close submenu': 'Закрити підменю',
	'Menu': 'Меню',
    'Open submenu': 'Відкрити підменю',
    'Toggle submenu': 'Перемкнути підменю'
};