export default {
    'cancel': 'abbrechen',
    'Cancel searching': 'Suche abbrechen',
    'Clear searchfield': 'Suchfeld löschen',
    'No results found.': 'Keine Ergebnisse gefunden.',
    'Search': 'Suche',
};
