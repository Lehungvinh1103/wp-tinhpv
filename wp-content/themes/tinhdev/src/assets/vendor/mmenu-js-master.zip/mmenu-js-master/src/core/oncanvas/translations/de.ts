export default {
    'Close submenu': 'Untermenü schließen',
	'Menu': 'Menü',
    'Open submenu': 'Untermenü öffnen',
    'Toggle submenu': 'Untermenü wechseln'
};
